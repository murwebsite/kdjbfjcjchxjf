<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
<?php
echo '<style>
  #mainplyr{display:none;}
  #bckplyr{display:block;}
  
  #mainplyr{width: 100%; height: 450px; overflow: hidden; position: relative;}
  #mainframe{position: absolute; top: -50px; left: 0;border:1px solid #transparent;}
  #bckplyr{width: 100%; height: 450px; overflow: hidden; position: relative;}
  #bckframe{position: absolute; top: -50px; left: 0;border:1px solid transparent;}
</style>';
?>

</head>
<body>