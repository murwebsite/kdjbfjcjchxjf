<?php
// Include the header file
include('header.php');
?>

<div id="mainplyr">
 <iframe id="mainframe" src="https://drive.google.com/file/d/1_0cwtJvnYq2EoPE68yUmRavWSW9lSRlu/preview" 
width="100%" height="300" allowfullscreen></iframe> 
</div> 
<div id="bckplyr">
 <iframe id="bckframe" src="https://drive.google.com/file/d/1VTQsby8StmNA28zogpgekX0qn5i_4Ekl/preview" 
width="100%" height="300" allowfullscreen></iframe> 
</div>

<?php
// Include the footer file
include('footer.php');
?>
